# Tiny Catan — Android App

This project wraps the supplied Tiny Catan HTML game in a simple offline Android app.

## Build it
1. Install Android Studio.
2. Open this folder (`TinyCatanAndroid`) in Android Studio.
3. Let Gradle sync/download the Android Gradle Plugin and SDK components if prompted.
4. Select **Build > Build APK(s)**.
5. Android Studio will show the generated APK location. Install that APK on your Android phone.

The game is bundled in `app/src/main/assets/index.html`, so it does not need internet access while playing.

Application ID: `com.tinycatan.pocket`
Version: 1.0
